/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../matrix/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[75];
    char stringdata0[1322];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 16), // "on_led11_clicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 16), // "on_led12_clicked"
QT_MOC_LITERAL(4, 46, 16), // "on_led13_clicked"
QT_MOC_LITERAL(5, 63, 16), // "on_led14_clicked"
QT_MOC_LITERAL(6, 80, 16), // "on_led15_clicked"
QT_MOC_LITERAL(7, 97, 16), // "on_led16_clicked"
QT_MOC_LITERAL(8, 114, 16), // "on_led17_clicked"
QT_MOC_LITERAL(9, 131, 16), // "on_led18_clicked"
QT_MOC_LITERAL(10, 148, 16), // "on_led21_clicked"
QT_MOC_LITERAL(11, 165, 16), // "on_led22_clicked"
QT_MOC_LITERAL(12, 182, 16), // "on_led23_clicked"
QT_MOC_LITERAL(13, 199, 16), // "on_led24_clicked"
QT_MOC_LITERAL(14, 216, 16), // "on_led25_clicked"
QT_MOC_LITERAL(15, 233, 16), // "on_led26_clicked"
QT_MOC_LITERAL(16, 250, 16), // "on_led27_clicked"
QT_MOC_LITERAL(17, 267, 16), // "on_led28_clicked"
QT_MOC_LITERAL(18, 284, 16), // "on_led31_clicked"
QT_MOC_LITERAL(19, 301, 16), // "on_led32_clicked"
QT_MOC_LITERAL(20, 318, 16), // "on_led33_clicked"
QT_MOC_LITERAL(21, 335, 16), // "on_led34_clicked"
QT_MOC_LITERAL(22, 352, 16), // "on_led35_clicked"
QT_MOC_LITERAL(23, 369, 16), // "on_led36_clicked"
QT_MOC_LITERAL(24, 386, 16), // "on_led37_clicked"
QT_MOC_LITERAL(25, 403, 16), // "on_led38_clicked"
QT_MOC_LITERAL(26, 420, 16), // "on_led41_clicked"
QT_MOC_LITERAL(27, 437, 16), // "on_led42_clicked"
QT_MOC_LITERAL(28, 454, 16), // "on_led43_clicked"
QT_MOC_LITERAL(29, 471, 16), // "on_led44_clicked"
QT_MOC_LITERAL(30, 488, 16), // "on_led45_clicked"
QT_MOC_LITERAL(31, 505, 16), // "on_led46_clicked"
QT_MOC_LITERAL(32, 522, 16), // "on_led47_clicked"
QT_MOC_LITERAL(33, 539, 16), // "on_led48_clicked"
QT_MOC_LITERAL(34, 556, 16), // "on_led51_clicked"
QT_MOC_LITERAL(35, 573, 16), // "on_led52_clicked"
QT_MOC_LITERAL(36, 590, 16), // "on_led53_clicked"
QT_MOC_LITERAL(37, 607, 16), // "on_led54_clicked"
QT_MOC_LITERAL(38, 624, 16), // "on_led55_clicked"
QT_MOC_LITERAL(39, 641, 16), // "on_led56_clicked"
QT_MOC_LITERAL(40, 658, 16), // "on_led57_clicked"
QT_MOC_LITERAL(41, 675, 16), // "on_led58_clicked"
QT_MOC_LITERAL(42, 692, 16), // "on_led61_clicked"
QT_MOC_LITERAL(43, 709, 16), // "on_led62_clicked"
QT_MOC_LITERAL(44, 726, 16), // "on_led63_clicked"
QT_MOC_LITERAL(45, 743, 16), // "on_led64_clicked"
QT_MOC_LITERAL(46, 760, 16), // "on_led65_clicked"
QT_MOC_LITERAL(47, 777, 16), // "on_led66_clicked"
QT_MOC_LITERAL(48, 794, 16), // "on_led67_clicked"
QT_MOC_LITERAL(49, 811, 16), // "on_led68_clicked"
QT_MOC_LITERAL(50, 828, 16), // "on_led71_clicked"
QT_MOC_LITERAL(51, 845, 16), // "on_led72_clicked"
QT_MOC_LITERAL(52, 862, 16), // "on_led73_clicked"
QT_MOC_LITERAL(53, 879, 16), // "on_led74_clicked"
QT_MOC_LITERAL(54, 896, 16), // "on_led75_clicked"
QT_MOC_LITERAL(55, 913, 16), // "on_led76_clicked"
QT_MOC_LITERAL(56, 930, 16), // "on_led77_clicked"
QT_MOC_LITERAL(57, 947, 16), // "on_led78_clicked"
QT_MOC_LITERAL(58, 964, 16), // "on_led81_clicked"
QT_MOC_LITERAL(59, 981, 16), // "on_led82_clicked"
QT_MOC_LITERAL(60, 998, 16), // "on_led83_clicked"
QT_MOC_LITERAL(61, 1015, 16), // "on_led84_clicked"
QT_MOC_LITERAL(62, 1032, 16), // "on_led85_clicked"
QT_MOC_LITERAL(63, 1049, 16), // "on_led86_clicked"
QT_MOC_LITERAL(64, 1066, 16), // "on_led87_clicked"
QT_MOC_LITERAL(65, 1083, 16), // "on_led88_clicked"
QT_MOC_LITERAL(66, 1100, 20), // "on_offButton_clicked"
QT_MOC_LITERAL(67, 1121, 20), // "on_redButton_clicked"
QT_MOC_LITERAL(68, 1142, 21), // "on_blueButton_clicked"
QT_MOC_LITERAL(69, 1164, 23), // "on_purpleButton_clicked"
QT_MOC_LITERAL(70, 1188, 25), // "on_generateButton_clicked"
QT_MOC_LITERAL(71, 1214, 25), // "on_offRadioButton_clicked"
QT_MOC_LITERAL(72, 1240, 25), // "on_redRadioButton_clicked"
QT_MOC_LITERAL(73, 1266, 26), // "on_blueRadioButton_clicked"
QT_MOC_LITERAL(74, 1293, 28) // "on_purpleRadioButton_clicked"

    },
    "MainWindow\0on_led11_clicked\0\0"
    "on_led12_clicked\0on_led13_clicked\0"
    "on_led14_clicked\0on_led15_clicked\0"
    "on_led16_clicked\0on_led17_clicked\0"
    "on_led18_clicked\0on_led21_clicked\0"
    "on_led22_clicked\0on_led23_clicked\0"
    "on_led24_clicked\0on_led25_clicked\0"
    "on_led26_clicked\0on_led27_clicked\0"
    "on_led28_clicked\0on_led31_clicked\0"
    "on_led32_clicked\0on_led33_clicked\0"
    "on_led34_clicked\0on_led35_clicked\0"
    "on_led36_clicked\0on_led37_clicked\0"
    "on_led38_clicked\0on_led41_clicked\0"
    "on_led42_clicked\0on_led43_clicked\0"
    "on_led44_clicked\0on_led45_clicked\0"
    "on_led46_clicked\0on_led47_clicked\0"
    "on_led48_clicked\0on_led51_clicked\0"
    "on_led52_clicked\0on_led53_clicked\0"
    "on_led54_clicked\0on_led55_clicked\0"
    "on_led56_clicked\0on_led57_clicked\0"
    "on_led58_clicked\0on_led61_clicked\0"
    "on_led62_clicked\0on_led63_clicked\0"
    "on_led64_clicked\0on_led65_clicked\0"
    "on_led66_clicked\0on_led67_clicked\0"
    "on_led68_clicked\0on_led71_clicked\0"
    "on_led72_clicked\0on_led73_clicked\0"
    "on_led74_clicked\0on_led75_clicked\0"
    "on_led76_clicked\0on_led77_clicked\0"
    "on_led78_clicked\0on_led81_clicked\0"
    "on_led82_clicked\0on_led83_clicked\0"
    "on_led84_clicked\0on_led85_clicked\0"
    "on_led86_clicked\0on_led87_clicked\0"
    "on_led88_clicked\0on_offButton_clicked\0"
    "on_redButton_clicked\0on_blueButton_clicked\0"
    "on_purpleButton_clicked\0"
    "on_generateButton_clicked\0"
    "on_offRadioButton_clicked\0"
    "on_redRadioButton_clicked\0"
    "on_blueRadioButton_clicked\0"
    "on_purpleRadioButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      73,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  379,    2, 0x08 /* Private */,
       3,    0,  380,    2, 0x08 /* Private */,
       4,    0,  381,    2, 0x08 /* Private */,
       5,    0,  382,    2, 0x08 /* Private */,
       6,    0,  383,    2, 0x08 /* Private */,
       7,    0,  384,    2, 0x08 /* Private */,
       8,    0,  385,    2, 0x08 /* Private */,
       9,    0,  386,    2, 0x08 /* Private */,
      10,    0,  387,    2, 0x08 /* Private */,
      11,    0,  388,    2, 0x08 /* Private */,
      12,    0,  389,    2, 0x08 /* Private */,
      13,    0,  390,    2, 0x08 /* Private */,
      14,    0,  391,    2, 0x08 /* Private */,
      15,    0,  392,    2, 0x08 /* Private */,
      16,    0,  393,    2, 0x08 /* Private */,
      17,    0,  394,    2, 0x08 /* Private */,
      18,    0,  395,    2, 0x08 /* Private */,
      19,    0,  396,    2, 0x08 /* Private */,
      20,    0,  397,    2, 0x08 /* Private */,
      21,    0,  398,    2, 0x08 /* Private */,
      22,    0,  399,    2, 0x08 /* Private */,
      23,    0,  400,    2, 0x08 /* Private */,
      24,    0,  401,    2, 0x08 /* Private */,
      25,    0,  402,    2, 0x08 /* Private */,
      26,    0,  403,    2, 0x08 /* Private */,
      27,    0,  404,    2, 0x08 /* Private */,
      28,    0,  405,    2, 0x08 /* Private */,
      29,    0,  406,    2, 0x08 /* Private */,
      30,    0,  407,    2, 0x08 /* Private */,
      31,    0,  408,    2, 0x08 /* Private */,
      32,    0,  409,    2, 0x08 /* Private */,
      33,    0,  410,    2, 0x08 /* Private */,
      34,    0,  411,    2, 0x08 /* Private */,
      35,    0,  412,    2, 0x08 /* Private */,
      36,    0,  413,    2, 0x08 /* Private */,
      37,    0,  414,    2, 0x08 /* Private */,
      38,    0,  415,    2, 0x08 /* Private */,
      39,    0,  416,    2, 0x08 /* Private */,
      40,    0,  417,    2, 0x08 /* Private */,
      41,    0,  418,    2, 0x08 /* Private */,
      42,    0,  419,    2, 0x08 /* Private */,
      43,    0,  420,    2, 0x08 /* Private */,
      44,    0,  421,    2, 0x08 /* Private */,
      45,    0,  422,    2, 0x08 /* Private */,
      46,    0,  423,    2, 0x08 /* Private */,
      47,    0,  424,    2, 0x08 /* Private */,
      48,    0,  425,    2, 0x08 /* Private */,
      49,    0,  426,    2, 0x08 /* Private */,
      50,    0,  427,    2, 0x08 /* Private */,
      51,    0,  428,    2, 0x08 /* Private */,
      52,    0,  429,    2, 0x08 /* Private */,
      53,    0,  430,    2, 0x08 /* Private */,
      54,    0,  431,    2, 0x08 /* Private */,
      55,    0,  432,    2, 0x08 /* Private */,
      56,    0,  433,    2, 0x08 /* Private */,
      57,    0,  434,    2, 0x08 /* Private */,
      58,    0,  435,    2, 0x08 /* Private */,
      59,    0,  436,    2, 0x08 /* Private */,
      60,    0,  437,    2, 0x08 /* Private */,
      61,    0,  438,    2, 0x08 /* Private */,
      62,    0,  439,    2, 0x08 /* Private */,
      63,    0,  440,    2, 0x08 /* Private */,
      64,    0,  441,    2, 0x08 /* Private */,
      65,    0,  442,    2, 0x08 /* Private */,
      66,    0,  443,    2, 0x08 /* Private */,
      67,    0,  444,    2, 0x08 /* Private */,
      68,    0,  445,    2, 0x08 /* Private */,
      69,    0,  446,    2, 0x08 /* Private */,
      70,    0,  447,    2, 0x08 /* Private */,
      71,    0,  448,    2, 0x08 /* Private */,
      72,    0,  449,    2, 0x08 /* Private */,
      73,    0,  450,    2, 0x08 /* Private */,
      74,    0,  451,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_led11_clicked(); break;
        case 1: _t->on_led12_clicked(); break;
        case 2: _t->on_led13_clicked(); break;
        case 3: _t->on_led14_clicked(); break;
        case 4: _t->on_led15_clicked(); break;
        case 5: _t->on_led16_clicked(); break;
        case 6: _t->on_led17_clicked(); break;
        case 7: _t->on_led18_clicked(); break;
        case 8: _t->on_led21_clicked(); break;
        case 9: _t->on_led22_clicked(); break;
        case 10: _t->on_led23_clicked(); break;
        case 11: _t->on_led24_clicked(); break;
        case 12: _t->on_led25_clicked(); break;
        case 13: _t->on_led26_clicked(); break;
        case 14: _t->on_led27_clicked(); break;
        case 15: _t->on_led28_clicked(); break;
        case 16: _t->on_led31_clicked(); break;
        case 17: _t->on_led32_clicked(); break;
        case 18: _t->on_led33_clicked(); break;
        case 19: _t->on_led34_clicked(); break;
        case 20: _t->on_led35_clicked(); break;
        case 21: _t->on_led36_clicked(); break;
        case 22: _t->on_led37_clicked(); break;
        case 23: _t->on_led38_clicked(); break;
        case 24: _t->on_led41_clicked(); break;
        case 25: _t->on_led42_clicked(); break;
        case 26: _t->on_led43_clicked(); break;
        case 27: _t->on_led44_clicked(); break;
        case 28: _t->on_led45_clicked(); break;
        case 29: _t->on_led46_clicked(); break;
        case 30: _t->on_led47_clicked(); break;
        case 31: _t->on_led48_clicked(); break;
        case 32: _t->on_led51_clicked(); break;
        case 33: _t->on_led52_clicked(); break;
        case 34: _t->on_led53_clicked(); break;
        case 35: _t->on_led54_clicked(); break;
        case 36: _t->on_led55_clicked(); break;
        case 37: _t->on_led56_clicked(); break;
        case 38: _t->on_led57_clicked(); break;
        case 39: _t->on_led58_clicked(); break;
        case 40: _t->on_led61_clicked(); break;
        case 41: _t->on_led62_clicked(); break;
        case 42: _t->on_led63_clicked(); break;
        case 43: _t->on_led64_clicked(); break;
        case 44: _t->on_led65_clicked(); break;
        case 45: _t->on_led66_clicked(); break;
        case 46: _t->on_led67_clicked(); break;
        case 47: _t->on_led68_clicked(); break;
        case 48: _t->on_led71_clicked(); break;
        case 49: _t->on_led72_clicked(); break;
        case 50: _t->on_led73_clicked(); break;
        case 51: _t->on_led74_clicked(); break;
        case 52: _t->on_led75_clicked(); break;
        case 53: _t->on_led76_clicked(); break;
        case 54: _t->on_led77_clicked(); break;
        case 55: _t->on_led78_clicked(); break;
        case 56: _t->on_led81_clicked(); break;
        case 57: _t->on_led82_clicked(); break;
        case 58: _t->on_led83_clicked(); break;
        case 59: _t->on_led84_clicked(); break;
        case 60: _t->on_led85_clicked(); break;
        case 61: _t->on_led86_clicked(); break;
        case 62: _t->on_led87_clicked(); break;
        case 63: _t->on_led88_clicked(); break;
        case 64: _t->on_offButton_clicked(); break;
        case 65: _t->on_redButton_clicked(); break;
        case 66: _t->on_blueButton_clicked(); break;
        case 67: _t->on_purpleButton_clicked(); break;
        case 68: _t->on_generateButton_clicked(); break;
        case 69: _t->on_offRadioButton_clicked(); break;
        case 70: _t->on_redRadioButton_clicked(); break;
        case 71: _t->on_blueRadioButton_clicked(); break;
        case 72: _t->on_purpleRadioButton_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 73)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 73;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 73)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 73;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
