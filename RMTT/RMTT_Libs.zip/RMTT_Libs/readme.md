# 如何更新 Arduino IDE 中的 RMTT_Libs？
## 1. 官方已集成 RMTT_Libs 版本
### 步骤1.更新库文件
使用 RMTT_Libs 文件夹替换 arduino-1.8.12\libraries\RMTT_Libs

### 步骤2.更新例程文件
使用 RMTT_Libs\examples 文件夹替换 arduino-1.8.12\hardware\espressif\esp32\libraries\RMTT_Examples\examples\

## 2. 非集成版但已安装旧版RMTT_Libs
使用 RMTT_Libs 文件夹替换 C:\Users\XXXX\Documents\Arduino\libraries\RMTT_Libs，XXXX为电脑用户名